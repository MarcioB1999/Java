package tarefas.lista1;

import java.util.Scanner;


public class questão1 {

  public static void main(String[] args) {
    int A, B;
    Scanner input= new Scanner(System.in);
    System.out.println("coloque um número");
    A= input.nextInt();
    System.out.println("agora coloque um segundo valor");
    B= input.nextInt();
    if(A>B){
      System.out.println("o maior é "+A);
    }else{
      if(A==B){
        System.out.println("os dois tem os mesmos valores "+A);
      }else{
        System.out.println("o maior é "+B);
      }
    }
  }
}
