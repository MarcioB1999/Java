package tarefas.lista3;
import java.util.Scanner;
public class ventiladorMain {
  public static void main(String[] args) {
    int opcao;
    ventilador A= new ventilador();
    Scanner input= new Scanner(System.in);
    do{
     do{
      System.out.println("1-ligar\n2-desligar\n3-aumentar\n4-diminuir\n5-ligar rotação\n6-desligar rotação\n7-estado");
      opcao= input.nextInt();
     }while(opcao<1||opcao>7);
     switch(opcao){
        case 1:
            A.ligar();
            break;
        case 2:
            A.desligar();
            break;
        case 3:
            A.aumentarVelo();
            break;
        case 4:
            A.diminuirVelo();
            break;
        case 5:
            A.ligarRota();
            break;
        case 6:
            A.desligarRota();
            break;
        case 7:
            A.estado();
            break;
       }
    }while(1!=0);
  }
  }
