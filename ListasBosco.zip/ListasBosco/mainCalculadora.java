package tarefas.lista3;
import java.util.Scanner;
public class mainCalculadora {
  public static void main(String[] args) {
    String A="", B="";
    double resultado=0;
    int opcao=0;
    Scanner input= new Scanner(System.in);
    exercicio calculadora= new exercicio();
    calculadora.novo();
    do{
      do{
        System.out.println("operações entre dois números\n 1-soma\n 2-subtração\n 3-multiplicação\n 4-divisão\n(para usar a resposta anterior use o X)");
       opcao= input.nextInt();
      }while(opcao<1 || opcao>4);
      switch(opcao){
        case 1:
            System.out.println("coloque os valores respectivamente A+B");
            A=input.next();
            B=input.next();
            resultado=calculadora.adicionar(A, B);
            break;
        case 2:
            System.out.println("coloque os valores respectivamente A-B");
            A=input.next();
            B=input.next();
            resultado=calculadora.subtrair(A, B);
            break;
        case 3:
            System.out.println("coloque os valores respectivamente AxB");
            A=input.next();
            B=input.next();
            resultado=calculadora.multiplicar(A, B);
            break;
        case 4:
            System.out.println("coloque os valores respectivamente A/B");
            A=input.next();
            B=input.next();
            resultado=calculadora.dividir(A, B);
            break;
      }
      System.out.println("resultado: "+resultado);
    }while(1!=0);
  }
}
