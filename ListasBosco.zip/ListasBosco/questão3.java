package tarefas.lista1;
import java.util.Scanner;
public class questão3 {
  public static void main(String[] args) {
     Scanner input= new Scanner(System.in);
     double A, B, C, raiz, delta, x1, x2, k;
     int i=0;
     System.out.println("coloque os coeficientes Ax^2+Bx+C,\ncom A diferente de 0, respectivamente");
     do{
       System.out.println("A:");
       A= input.nextDouble();
       if(A==0){
         System.out.println("coloque um valor diferente de 0 para A");
       }
     }while(A==0);
     System.out.println("B:");
     B= input.nextDouble();
     System.out.println("C:");
     C= input.nextDouble();
     delta=B*B-4*A*C;
     System.out.println("delta:"+delta);
     raiz= Math.sqrt(delta);
     if(delta==0){
       x1=x2=(-B)/(2*A);
       System.out.println("x1="+x1+"\nx2="+x2);
     }else{
       if(delta>0){
         x1=(-B-raiz)/(2*A);
         x2=(-B+raiz)/(2*A);
         System.out.println("x1="+x1+"\nx2="+x2);
       }else{
         delta=(-1)*(B*B-4*A*C);
         k=(-B)/(2*A);
         raiz=Math.sqrt(delta);
         System.out.println("x1="+k+"+i"+raiz/(2*A));
         System.out.println("x2="+k+"-i"+raiz/(2*A));
       }
     }
  }
}