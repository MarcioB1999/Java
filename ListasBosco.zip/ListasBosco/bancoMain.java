package tarefas.lista2;
import java.util.Scanner;
public class bancoMain {
  public static void main(String[] args) {
    int opcao=0;
    double valor=0;
    banco banco=new banco();
    banco.Banco();
    Scanner input= new Scanner(System.in);
    String numero="";
    String numero2="";
    do{
      do{
      System.out.println("1-cadastrar\n2-debitar\n3-creditar\n4-saldo\n5-transferir");
      opcao=input.nextInt();
      }while(opcao<0||opcao>5);
      switch(opcao){
        case 1:
           System.out.println("coloque o número desejado do tipo XX.XXX-X\n(é necessário que sejam colocados os pontos e traços)");
           numero=input.next();
           Conta conta= new Conta(numero);
           banco.cadastrar(conta);
           break;
       case 2:
          System.out.println("coloque o valor");
          valor=input.nextDouble();
          System.out.println("coloque o número");
          numero=input.next();
          banco.debitar(numero, valor);
          break;
       case 3:
          System.out.println("coloque o valor");
          valor=input.nextDouble();
          System.out.println("coloque o número");
          numero=input.next();
          banco.creditar(numero, valor);
          break;
       case 4:
          System.out.println("coloque o número");
          numero=input.next();
          System.out.println(""+banco.saldo(numero));
          break;
       case 5:
          System.out.println("coloque o número de origem");
          numero=input.next();
          System.out.println("coloque o número de destino");
          numero2=input.next();
          System.out.println("coloque o valor");
          valor=input.nextDouble();
          banco.transferir(numero, numero2, valor);
      }
      
    }while(1!=0);
  }
}
