package tarefas.lista3;

public class ventilador {
     int velocidade=0; 
     boolean ligar=false;
     boolean rotação=false;
     public void aumentarVelo(){
       if(ligar==true && velocidade<5){
         ++velocidade;
       }
       return;
     }
     public void diminuirVelo(){
       if(ligar==true && velocidade<5){
         --velocidade;
       }
     }
     public void desligar(){
       ligar=false;
     }
     public void ligar(){
       ligar=true;
     }
     public void desligarRota(){
       if(ligar==true){
         rotação=false;
        }
     }
     public void ligarRota(){
       if(ligar==true){
         rotação=true;
        }
     }
     public void estado(){
       System.out.println("ligar:"+ligar+"rotação:"+rotação+"velocidade:"+velocidade);
     }
     
     
}
