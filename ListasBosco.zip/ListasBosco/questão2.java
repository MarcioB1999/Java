package tarefas.lista1;
import java.util.Scanner;
public class questão2 {
  public static void main(String[] args) {
    double A, B, resultado=0;
    int opcao=0;
    Scanner input= new Scanner(System.in);
    do{
       System.out.println("operações entre dois números\n 1-soma\n 2-subtração\n 3-multiplicação\n 4-divisão");
       opcao= input.nextInt();
       if(opcao==1){
         System.out.println("coloque o valor A");
         A= input.nextDouble();
         System.out.println("coloque o valor B");
         B= input.nextDouble();
         resultado=A+B;
       }else{
         if(opcao==2){
           System.out.println("a operação sera realizada da seguinte forma A-B");
           System.out.println("coloque o valor A");
           A= input.nextDouble();
           System.out.println("coloque o valor B");
           B= input.nextDouble();
           resultado=A-B;
         }else{
           if(opcao==3){
             System.out.println("coloque o valor A");
             A= input.nextDouble();
             System.out.println("coloque o valor B");
             B= input.nextDouble();
             resultado=A*B;
           }else{
             System.out.println("a operação sera realizada da seguinte forma A/B");
             System.out.println("coloque o valor A");
             A= input.nextDouble();
             System.out.println("coloque o valor B");
             B= input.nextDouble(); 
             resultado=A/B;
           }
         }
       }
       System.out.println("o resultado é: "+resultado);
    }while(1!=0);
  }
}
