package tarefas.lista2;
import java.util.Scanner;
public class calculadora {
   double operandoA, operandoB, radianos, radicando, base;
   int expoente;
/////////////////////////////////////////
   public static double tangente(double radianos){
     return Math.tan(radianos);
   }
/////////////////////////////////////////
   public static double coseno(double radianos){
     return Math.cos(radianos);
   }
/////////////////////////////////////////
   public static double seno(double radianos){
     return Math.sin(radianos);
   }
/////////////////////////////////////////
   public static double raiz(double radicando){
     return Math.sqrt(radicando);
   }
/////////////////////////////////////////
   public static double potencia(double base, int expoente){
     return Math.pow(base, expoente);
   }
/////////////////////////////////////////
   public static double adicionar(double operandoA, double operandoB){
     return operandoA+operandoB;
   }
/////////////////////////////////////////
   public static double subtrair(double operandoA, double operandoB){
     return operandoA-operandoB;
   }
/////////////////////////////////////////
   public static double multiplicar(double operandoA, double operandoB){
     return operandoA*operandoB;
   }
/////////////////////////////////////////
   public static double dividir(double operandoA, double operandoB){
     return operandoA/operandoB;
   }
}


