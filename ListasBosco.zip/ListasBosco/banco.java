package tarefas.lista2;

public class banco {
    private Conta[] contas;
    private int indice=0;
public void Banco(){
  contas=new Conta[100];
}
public void cadastrar(Conta conta){
  contas[indice]=conta;
  indice++;
}
private Conta procurar(String numero){
  int i=0;
  while(i<indice){
    if(numero.equals(contas[i].numero())){
      break;
    }else{
      i++;
    }
  }
  return contas[i];
}
public void creditar(String numero, double valor){
   if(procurar(numero)!=null){
    procurar(numero).creditar(valor);
  }else{
    System.out.println("nao foi possivel\n realizar a operação");
  }
  }
public void debitar(String numero, double valor){
  if(procurar(numero)!=null){
    procurar(numero).debitar(valor);
  }else{
    System.out.println("nao foi possivel\nrealizar a operação");
  }
}
public double saldo(String numero){
   if(procurar(numero)!=null){
    return procurar(numero).saldo();
  }else{
    System.out.println("nao foi possivel\nrealizar a operação");
    return 1;
  }
}
public void transferir(String origem, String destino, double valor){
     if(procurar(origem)!=null){
    procurar(origem).debitar(valor);
  }else{
    System.out.println("nao foi possivel\nrealizar a operação");
  }
     if(procurar(destino)!=null){
    procurar(destino).creditar(valor);
  }else{
    System.out.println("nao foi possivel\nrealizar a operação");
  }
}
}