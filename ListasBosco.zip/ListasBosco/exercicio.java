package tarefas.lista3;
import java.util.Scanner;
public class exercicio {
     String operandoA="", operandoB="";
     double op1, op2, ans;
     public void novo(){
       ans=0;
     }
     public double converter(String A){
       double k=0;
       if(A.equals("x")){
         k=ans;
       }else{
         k= Double.parseDouble(A);
       }
       return k;
     }
     
     public double adicionar(String operandoA, String operandoB){
     op1=converter(operandoA);
     op2=converter(operandoB);
     ans=op1+op2;
     return ans;
    }
    public double subtrair(String operandoA, String operandoB){
     op1=converter(operandoA);
     op2=converter(operandoB);
     ans=op1-op2;
     return ans;
   }
   public double multiplicar(String operandoA, String operandoB){
     op1=converter(operandoA);
     op2=converter(operandoB);
     ans=op1*op2;
     return ans;
    
   }
      public double dividir(String operandoA, String operandoB){
     op1=converter(operandoA);
     op2=converter(operandoB);
     ans=op1/op2;
     return ans;
    
   }
}